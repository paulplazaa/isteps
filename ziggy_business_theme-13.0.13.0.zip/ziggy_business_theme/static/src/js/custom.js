$('body').delay(500).addClass('loaded').find('.page-loader').fadeOut(1000);
    //About Tabs
    jQuery('.tabs .tab-links a').on('click', function(e) {
        var currentAttrValue = jQuery(this).attr('href');

        // Show/Hide Tabs
        jQuery('.tabs ' + currentAttrValue).fadeIn(500).siblings().hide();;

        // Change/remove current tab to active
        jQuery(this).parent('li').addClass('active').siblings().removeClass('active');

        e.preventDefault();
});

//Features Tabs
jQuery('.features-tabs .carousel-tabs li a').on('click', function(e) {
    var currentAttrValue = jQuery(this).attr('href');

    // Show/Hide Tabs
    jQuery('.features-tabs ' + currentAttrValue).fadeIn(500).siblings().hide();;

    // Change/remove current tab to active
    jQuery('.carousel-tabs li').removeClass('active');
    jQuery('.carousel-tabs a[href$="' + currentAttrValue + '"]').parent().addClass('active');

    e.preventDefault();
});

//Skill Progress Bar
$('.skill-progress-bar > span').each(function() {
    var $this = $(this);
    var width = $(this).data('percent');
    $this.css({
        'transition': 'width 2.5s'
    });

    setTimeout(function() {
        $this.filter(':visible').waypoint(function(direction) {
            if (direction === 'down') {
                $this.css('width', width + '%');
            }
        }, {
            offset: '100%'
        });
    }, 500);
});