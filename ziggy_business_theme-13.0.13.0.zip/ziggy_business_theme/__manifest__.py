{
    'name': 'Ziggy Business Theme',
    'summary': 'Ziggy Business Theme',
    'description': """
    Business Website Theme.

    - Use finely designed building blocks and edit everything inline. 
    - Super Clean Snippets.
    - Fully and Easy Customizable
    - Responsive content on all pages.
    - Edit Anything Inline.
    """,
    'category': 'Theme/Creative',
    'version': '13.0',
    'license': 'LGPL-3',
    'author': 'Key Concepts',
    'website': 'http://keyconcepts.co.in',
    'depends': ['website', 'crm'],
    'images': [],
    'data': [
        'views/theme_source.xml',
        'views/snippets.xml',
    ],
    "sequence": 1,
    'installable': True,
    'application':True,
    'price': 29,
    'currency': "EUR",
    'images': [
                'static/description/ziggy_poster.jpg',
                'static/description/ziggy_screenshot.jpg'
                ],
    'live_test_url': 'http://ziggy.kcits.co.in',
}
